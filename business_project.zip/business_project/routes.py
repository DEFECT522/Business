from flask import Blueprint, render_template, redirect, url_for, flash, request, current_app, abort
from .forms import RegisterForm, LoginForm, GoalForm
from .models import User, Goal
from . import db, login_manager
from werkzeug.security import generate_password_hash, check_password_hash
from flask_login import login_user, current_user, logout_user, login_required

bp = Blueprint('main', __name__)

# load user for flask-login
@login_manager.user_loader
def load_user(user_id):
    return db.session.get(User, int(user_id))

def require_first_user(func):
    # decorator to ensure only user with ID == 1 can access
    from functools import wraps
    @wraps(func)
    def wrapper(*args, **kwargs):
        if not current_user.is_authenticated:
            return login_manager.unauthorized()
        if current_user.id != 1:
            flash('الوصول محظور — هذه المناطق محجوزة لمالك الحساب الأول فقط.', 'danger')
            return redirect(url_for('main.home'))
        return func(*args, **kwargs)
    return wrapper

@bp.route('/')
def home():
    # public home page
    return render_template('home.html')

@bp.route('/register', methods=['GET', 'POST'])
def register():
    if current_user.is_authenticated:
        flash('أنت مسجل دخول بالفعل.', 'info')
        # redirect to secret home if allowed or public home otherwise
        if current_user.id == 1:
            return redirect(url_for('main.secret_home'))
        return redirect(url_for('main.home'))

    form = RegisterForm()
    if form.validate_on_submit():
        # create user
        hashed = generate_password_hash(form.password.data)
        new_user = User(username=form.username.data.strip(), email=form.email.data.strip(), password_hash=hashed)
        db.session.add(new_user)
        db.session.commit()
        flash('تم إنشاء الحساب بنجاح. سجل دخول الآن.', 'success')
        return redirect(url_for('main.login'))
    return render_template('register.html', form=form)

@bp.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        flash('أنت مسجل دخول بالفعل.', 'info')
        if current_user.id == 1:
            return redirect(url_for('main.secret_home'))
        return redirect(url_for('main.home'))

    form = LoginForm()
    if form.validate_on_submit():
        user = db.session.execute(db.select(User).filter_by(email=form.email.data.strip())).scalar_one_or_none()
        if user and check_password_hash(user.password_hash, form.password.data):
            login_user(user)
            flash('تم تسجيل الدخول.', 'success')
            # do not auto-redirect to secret unless ctrl+shift+d is pressed by user — but we'll redirect to secret if user is first
            if user.id == 1:
                return redirect(url_for('main.secret_home'))
            return redirect(url_for('main.home'))
        else:
            flash('بيانات غير صحيحة.', 'danger')
    return render_template('login.html', form=form)

@bp.route('/logout')
@login_required
def logout():
    logout_user()
    flash('تم تسجيل الخروج.', 'info')
    return redirect(url_for('main.home'))

@bp.route('/secret')
@login_required
@require_first_user
def secret_home():
    # secret dashboard for user id==1
    goals = db.session.execute(db.select(Goal).filter_by(user_id=current_user.id)).scalars().all()
    total_points = sum(g.points for g in goals)
    count_goals = len(goals)
    avg_percent = 0
    if count_goals > 0:
        avg_percent = sum((g.points/365)*100 for g in goals) / count_goals
    return render_template('secret_home.html', goals=goals, total_points=total_points, count_goals=count_goals, avg_percent=avg_percent)

@bp.route('/goals')
@login_required
@require_first_user
def goals():
    goals = db.session.execute(db.select(Goal).filter_by(user_id=current_user.id)).scalars().all()
    return render_template('goals.html', goals=goals)

@bp.route('/add_goal', methods=['POST'])
@login_required
@require_first_user
def add_goal():
    form = GoalForm()
    if form.validate_on_submit():
        title = form.title.data.strip()
        desc = form.description.data.strip() if form.description.data else ''
        g = Goal(title=title, description=desc, user_id=current_user.id, points=0)
        db.session.add(g)
        db.session.commit()
        flash('تم إضافة الهدف.', 'success')
    else:
        flash('خطأ في بيانات الهدف.', 'danger')
    return redirect(url_for('main.secret_home'))

@bp.route('/update_points/<int:goal_id>/<action>', methods=['POST'])
@login_required
@require_first_user
def update_points(goal_id, action):
    goal = db.session.get(Goal, goal_id)
    if not goal or goal.user_id != current_user.id:
        flash('الهدف غير موجود أو غير مصرح.', 'danger')
        return redirect(url_for('main.goals'))
    if action == 'plus':
        goal.points = min(365, goal.points + 1)
    elif action == 'minus':
        goal.points = max(0, goal.points - 1)
    db.session.commit()
    return redirect(request.referrer or url_for('main.goals'))