from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SubmitField, TextAreaField
from wtforms.validators import DataRequired, Length, Email, EqualTo, ValidationError
import re
from .models import User
from . import db

class RegisterForm(FlaskForm):
    username = StringField('User Name', validators=[DataRequired(), Length(min=2, max=25)])
    email = StringField('Email', validators=[DataRequired(), Email(), Length(max=120)])
    password = PasswordField('Password', validators=[DataRequired(), Length(min=8, max=32)])
    confirm_password = PasswordField('Confirm Password', validators=[DataRequired(), EqualTo('password')])
    submit = SubmitField('Sign Up')

    def validate_username(self, username):
        user = db.session.execute(db.select(User).filter_by(username=username.data)).scalar_one_or_none()
        if user:
            raise ValidationError('اسم المستخدم مأخوذ، جرّب اسم تاني.')

    def validate_email(self, email):
        user = db.session.execute(db.select(User).filter_by(email=email.data)).scalar_one_or_none()
        if user:
            raise ValidationError('هذا الإيميل مستخدم بالفعل.')

    def validate_password(self, password):
        pw = password.data
        if len(pw) < 8 or len(pw) > 32:
            raise ValidationError('كلمة المرور لازم تكون بين 8 و 32 حرف/رمز.')
        if not re.search(r'\d', pw):
            raise ValidationError('كلمة المرور لازم تحتوي رقم واحد على الأقل.')
        if not re.search(r'[A-Z]', pw):
            raise ValidationError('كلمة المرور لازم تحتوي حرف كبير واحد على الأقل.')
        if not re.search(r'[a-z]', pw):
            raise ValidationError('كلمة المرور لازم تحتوي حرف صغير واحد على الأقل.')
        if not re.search(r'[^\w\s]', pw):
            raise ValidationError('كلمة المرور لازم تحتوي رمز خاص واحد على الأقل (مثل !@#$%).')

class LoginForm(FlaskForm):
    email = StringField('البريد الإلكتروني', validators=[DataRequired(), Email(), Length(max=120)])
    password = PasswordField('كلمة المرور', validators=[DataRequired()])
    submit = SubmitField('تسجيل الدخول')

class GoalForm(FlaskForm):
    title = StringField('اسم الهدف', validators=[DataRequired(), Length(max=140)])
    description = TextAreaField('وصف الهدف (اختياري)', validators=[Length(max=1000)])
    submit = SubmitField('إضافة الهدف')