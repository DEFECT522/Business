from . import create_app

app = create_app()

if __name__ == "__main__":
    # For development / local testing
    app.run(port=5000, debug=True)